package command;

/**
 * GetAllFilesDescCommand command 
 * 
 */
public class GetAllFilesDescCommand extends Command {

	public GetAllFilesDescCommand(int numCommand) {
		super(numCommand);
	}
	//getFileDesc

}
