====================================================================
Description :
====================================================================
Connect
Load Schema
Insert Data
Select all the data from all tables
Disconnect

Doc1 connects
Select on Events with access control
Insert Events
Doc1 disconnects

Soc connects
Select on Events with access control
Soc disconnects

Doc2 connects
Select on Events with access control
Doc2 disconnects

Connect
Unload Schema
Disconnect

