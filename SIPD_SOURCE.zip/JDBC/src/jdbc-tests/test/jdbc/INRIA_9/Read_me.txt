====================================================================
Description :
====================================================================
Connect
Load Schema
Insert Data
Select all the tuples from Events
Select all the tuples from Info

Delete the tuples of info by IdEvent

Select all the tuples from TupleDeleted
Select all the tuples from LogDeleted

Select all the tuples from Events
Select all the tuples from Info

Unload Schema
Disconnect
