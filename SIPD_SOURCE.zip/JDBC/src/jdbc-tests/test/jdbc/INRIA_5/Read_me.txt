====================================================================
Description :
====================================================================
Connect
Load Schema
Insert Data
Select all the tuples from Info

Update in table info a field not indexed of the tuple of a given Id I
Select all the tuples from Info

Update in table info a field not indexed of the tuple of a given Id
Select all the tuples from Info

Update again in table info a field not indexed of the tuple of the Id I
Select all the tuples from Info

Unload Schema
Disconnect
