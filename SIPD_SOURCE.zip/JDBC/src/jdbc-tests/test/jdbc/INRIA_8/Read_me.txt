====================================================================
Description :
====================================================================
Connect
Load Schema
Insert Data
Select all the tuples from Info

update Info set ValChar = " + newValue + " where Info.IdGlobal = " + "0x000000000000000000000000000000000000015e
Select all the tuples from Info

commit

update Info set ValChar = " + newValue + " where Info.IdGlobal = " + "0x000000000000000000000000000000000000015e
update Info set ValChar = " + newValue + " where Info.IdGlobal = " + "0x00000000000000000000000000000000000001c4
update Info set ValChar = " + newValue + " where Info.IdGlobal = " + "0x00000000000000000000000000000000000001c5

Select all the tuples from Info

Rollback_Transaction

Select all the tuples from Info

Unload Schema
Disconnect
