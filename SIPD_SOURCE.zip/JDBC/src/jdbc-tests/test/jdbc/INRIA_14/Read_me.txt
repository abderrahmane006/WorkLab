====================================================================
Description :
====================================================================
Load Schema
Insert large size comments (400x)
Select all the data from all tables
Unload Schema


