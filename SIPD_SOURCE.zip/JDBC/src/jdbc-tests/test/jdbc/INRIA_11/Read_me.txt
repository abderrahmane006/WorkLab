====================================================================
Description :
====================================================================
Load Schema

Insert Data
Select * from event
Select * from info
commit

Insert 1 tuples into table EVENT
Insert 10 tuples into table INFO
Select * from event
Select * from info

Rollback_Transaction

Select * from event
Select * from info

Unload Schema


